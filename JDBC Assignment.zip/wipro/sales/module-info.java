module wipro {
	requires java.sql;
}